ESX = exports['es_extended']:getSharedObject()

RegisterNetEvent('mp-wroof:client:notify', function(message, type)
    lib.notify({
        title = Config.NotifyTitle,
        description = message,
        type = type, 
        position = 'center-right',
        iconAnimation = 'spinPulse',
    })
end)

for _, coords in pairs(Config.Coordinates) do 
    exports.ox_target:addBoxZone({
        coords = coords, 
        size = vec3(2, 2, 2),
        rotation = 45,
        options = {
            {
                name = 'box',
                event = 'mp-wroof:client:check',
                icon = Config.OxIcon,
                label = Config.OxLabel
            }
        }
    })
end

RegisterNetEvent('mp-wroof:client:check')
AddEventHandler('mp-wroof:client:check', function()
    TriggerServerEvent('mp-wroof:server:itemCheck')
end)

RegisterNetEvent('mp-wroof:client:startRoof')
AddEventHandler('mp-wroof:client:startRoof', function()
        local job = Config.Job
        local message = Config.SmashMessage


    local result = exports['lockpick']:startLockpick()

    if result then
        local progress = lib.progressCircle({
            duration = Config.ProgressTime * 1000,
            position = 'bottom',
            useWhileDead = false,
            canCancel = true,
            label = Config.ProgressLabel,
            disable = {car = true, move = true},
            anim = {
             dict = 'anim@heists@prison_heiststation@cop_reactions',
             clip = 'cop_b_idle'
            },
        })

        if progress then
            TriggerServerEvent('mp-wroof:server:StartPayment')
        end
    else
      SendNotify(message, job)
    end
end)


function SendNotify(message, job)
    if Config.Notify == "phone" then
        exports["roadphone"]:sendDispatch(Config.SmashMessage, Config.Job)

    elseif Config.Notify == "esx" then
     TriggerServerEvent('mp-wroof:server:dispatch', Config.SmashMessage)


    elseif Config.Notify == "ox" then
        lib.notify({
            title = Config.NotifyTitle,
            description = message,
            type = "inform"
        })
    end
end
