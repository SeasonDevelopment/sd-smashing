Config = {}

-- Coordinates
Config.Coordinates = { -- The coordinates where the target will be created for the robbery
    vec3(237.0455, -876.4078, 30.4921),
    vec3(24.4713, -1344.9821, 29.4970)
--  vec3(0, 0, 0),
--  vec3(0, 0, 0),
--  vec3(0, 0, 0),
--  vec3(0, 0, 0),
--  vec3(0, 0, 0),
--  vec3(0, 0, 0),
--  vec3(0, 0, 0),
--  vec3(0, 0, 0),
--  vec3(0, 0, 0)
}

-- Messages
Config.NotifyTitle = 'Store robbery' -- The title of the Notify
Config.CooldownMessage = 'There is still an cooldown for: '
Config.ProgressLabel = "Smashing Register..." -- Progressbar label 
Config.MissingItem = 'Required items are missing'
Config.OxLabel = 'Smash register' -- Text used for target
Config.OxIcon = 'fa-solid fa-gun' -- Icon used for target

-- Police Notifications
Config.Notify = "esx" -- options: "phone", "esx", "ox"
Config.Job = "police" -- Job that receives message
Config.SmashMessage = "Someone tried to smash an register" -- The message the police gets

-- Robbery start
Config.MinCash = 384 -- The minimum amount of money the player receives
Config.MaxCash = 394 -- The maximum amount of money the player receives
Config.Account = 'money' -- the account where the player receives the money, e.g. 'cash', 'bank', 'money', 'dirty_money'
Config.Item = 'lockpick' -- Item needed for the robbery, e.g. 'lockpick'
Config.Cooldown = 50 -- The countdown before doing another robbery in seconds, e.g. 60 seconds
Config.ProgressTime = 5 -- Time of progressbar in seconds


