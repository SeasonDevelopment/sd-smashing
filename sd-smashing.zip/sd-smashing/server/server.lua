ESX = exports['es_extended']:getSharedObject()

local playerCooldowns = {}

RegisterNetEvent('mp-wroof:server:itemCheck', function()
    local src = source 
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return end

    local itemCount = xPlayer.getInventoryItem(Config.Item).count
    local lastTime = playerCooldowns[src] or 0
    local now = os.time()

    if now - lastTime < Config.Cooldown then
        local remaining = Config.Cooldown - (now - lastTime)
        TriggerClientEvent('mp-wroof:client:notify', src,
            Config.CooldownMessage .. remaining .. ' seconds',
            'error')
        return
    end

    if itemCount > 0 then
        xPlayer.removeInventoryItem(Config.Item, 1)
        playerCooldowns[src] = now
        TriggerClientEvent('mp-wroof:client:startRoof', src)
    else
        TriggerClientEvent('mp-wroof:client:notify', src, Config.MissingItem, 'error')
    end
end)

RegisterNetEvent('mp-wroof:server:StartPayment', function()
    local src = source 
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return end

    local random = math.random(Config.MinCash, Config.MaxCash)
    xPlayer.addAccountMoney(Config.Account, random)

end)

RegisterNetEvent('mp-wroof:server:dispatch', function(message)
    local xPlayers = ESX.GetExtendedPlayers()

    for _, xPlayer in pairs(xPlayers) do
        if xPlayer.job.name == Config.Job then
            TriggerClientEvent('mp-wroof:client:notifyPolice', xPlayer.source, message)
        end
    end
end)
