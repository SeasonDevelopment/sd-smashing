-----------------For support, scripts, and more----------------
--------------- https://discord.gg/wasabiscripts  -------------
---------------------------------------------------------------
fx_version 'cerulean'
game 'gta5'
lua54 'yes'


version '1.1.2'

shared_scripts {
  '@ox_lib/init.lua',
  'config.lua'
}

dependency 'lockpick'

client_scripts {
  'client/client.lua',
}

server_scripts {
  '@mysql-async/lib/MySQL.lua',
  'server/*.lua'
}




